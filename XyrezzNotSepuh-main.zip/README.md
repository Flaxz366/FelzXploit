PASANG DI FILE package.json 
```
"whiskeyshocket/Baileys": "github:Awafff/XyrezzNotSepuh",
```
<br><br><br>
<a href="https://whatsapp.com/channel/0029VacxTsC8F2p5dshCmq3r">MY CHANNEL OFFICIAL #1</a><br><br>
<a href="https://whatsapp.com/channel/0029VaofHDeI7BeLcrFY9744">MY CHANNEL OFFICIAL #2</a><br><br>
<a href="https://www.youtube.com/@RerezzOffc">MY YOUTUBE CHANNEL</a><br><br>
<a href="https://free.for.all.by.xyrezz.shopwebsite.my.id">WEBSITE KUMPUL SC FREE</a><br><br><br><br><br>


<a href="https://github.com/Awafff">© Rerezz Official</a><br>
<a href="https://github.com/KyuuRzy">© KyuuRzy</a>
